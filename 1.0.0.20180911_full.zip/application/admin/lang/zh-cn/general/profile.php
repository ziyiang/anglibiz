<?php

return [
    'Url'                                         => '链接',
    'Userame'                                     => '用户名',
    'Createtime'                                  => '操作时间',
    'Click to edit'                               => '点击编辑',
    'Admin log'                                   => '操作日志',
    'Leave password blank if dont want to change' => '不修改密码请留空',
];
